#-*- coding: utf-8 -*-
#del.icio.us 网站已升级 原API失效

import pydelicious
#pydelicious.get_popular(tag='programming')
#pydelicious.get_userpost('dorisa')

"""
from deliciousrec import *
delusers = initializeUserDict('programming')
delusers ['tsegaran'] = {}
fillItems(delusers)

import random
import recommendations
user = delusers.keys()[random.randint(0, len(delusers) - 1)]
print user

print recommendations.topMatches(delusers, user)

print recommendations.getRecommendations(delusers, user)[0 : 10]

url = recommendations.getRecommendations(delusers, user)[0][1]
print recommendations.topMatches(recommendations.transformPrefs(delusers), url)
"""
